report file.docx和report file.pdf是实验报告。
Dijkstra_Algorithm.py和Distance_Vector.py是源代码。
Dijkstra.ipynb和Distance_Vector.ipynb我更喜欢用ipython写代码。
Dijkstra_Algorithm计算过程使用了import heapq函数库用于处理堆（heap）数据结构。