# TIME : 2023/11/2 21:05

import socket
import time

server_port = 12000  # 服务器端口
server_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)  # 创建UDP套接字
server_socket.bind(('', server_port))  # 绑定地址和端口

print('The server is ready to receive')  # 打印服务器就绪信息

while True:
    message, client_address = server_socket.recvfrom(2048)  # 接收消息和客户端地址

    # 模拟服务器端响应时间过长，增加了 2 秒延迟
    time.sleep(2)

    modified_message = message.decode().upper()  # 转换为大写
    server_socket.sendto(modified_message.encode(), client_address)  # 发送转换后的消息给客户端
