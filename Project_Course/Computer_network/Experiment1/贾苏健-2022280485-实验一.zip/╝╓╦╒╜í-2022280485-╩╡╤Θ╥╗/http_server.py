# TIME : 2023/10/16 21:05

import socket
import os
from datetime import datetime


def handle_client(client_socket):
    request = client_socket.recv(1024)
    request_lines = request.decode().split('\r\n')

    if len(request_lines) > 0:
        request_parts = request_lines[0].split()
        if len(request_parts) >= 2:
            method = request_parts[0]
            filename = request_parts[1]

            print(f"Received request for {filename}")  # 打印接收到的请求文件名

            if method == 'GET':
                if filename == '/':
                    filename = '/index.html'

                filename = filename.lstrip('/')
                filename = os.path.abspath(os.path.join("files/", filename))

                print(f"Requested file path: {filename}")  # 打印文件路径

                if os.path.exists(filename) and os.path.isfile(filename):
                    with open(filename, "r") as file:
                        content = file.read()
                    # test begin
                    # print(f"Content length: {len(content)}")
                    # print(content)  # 添加这行来查看文件内容是否被正确读取
                    # test end

                    response = "HTTP/1.1 200 OK\r\n"
                    response += f"Date: {datetime.now().strftime('%a, %d %b %Y %H:%M:%S GMT')}\r\n"
                    response += "Server: Apache/2.4.6 (CentOS) OpenSSL/1.0.2k-fips PHP/7.4.9 mod_perl/2.0.11 Perl/v5.16.3\r\n"
                    response += f"Last-Modified: {datetime.now().strftime('%a, %d %b %Y %H:%M:%S GMT')}\r\n"
                    response += "ETag: \"a5b-52d015789ee9e\"\r\n"
                    response += "Accept-Ranges: bytes\r\n"
                    response += f"Content-Length: {len(content)}\r\n"
                    response += "Content-Type: text/html; charset=UTF-8\r\n\r\n"
                    response += content

                    print("Sending HTTP response:")  # 打印发送的HTTP响应消息
                    print(response)

                    client_socket.send(response.encode())
                else:
                    response = "HTTP/1.1 404 Not Found\r\n"
                    response += "Content-Type: text/html; charset=UTF-8\r\n\r\n"
                    response += "<h1>404 Not Found</h1>"

                    print("File not found. Sending 404 response")  # 打印文件未找到信息
                    print("Sending HTTP response:")  # 打印发送的HTTP响应消息
                    print(response)

                    client_socket.send(response.encode())

    client_socket.close()


def main():
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind(('127.0.0.1', 8081))
    server.listen(5)

    print('Web服务器正在监听端口 127.0.0.1:8081...')

    while True:
        client_socket, addr = server.accept()
        print(f'接收到来自 {addr} 的连接')

        handle_client(client_socket)

        print("Request handled. Waiting for new connections...")  # 打印请求处理完毕，等待新连接


if __name__ == "__main__":
    main()
