# TIME : 2023/10/30 20:13

import socket
import os

# 创建一个TCP套接字
server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# 绑定套接字到特定的地址和端口
server_address = ('127.0.0.1', 12345)
server_socket.bind(server_address)

# 监听客户端连接
server_socket.listen(1)
print("等待客户端连接...")

while True:
    # 等待客户端连接
    client_socket, client_address = server_socket.accept()
    print(f"连接来自 {client_address}")

    # 接收文件名请求
    file_name = client_socket.recv(1024).decode()

    # 检查文件是否存在
    if os.path.exists(file_name):
        print(f"找到文件: {file_name}")
        # 打开并发送文件
        with open(file_name, 'rb') as file:
            file_data = file.read()
            client_socket.send(file_data)
        print(f"已发送文件: {file_name}")
    else:
        # 发送错误消息
        error_message = "文件不存在"
        client_socket.send(error_message.encode())
        print("发送错误消息：文件不存在")

    # 关闭客户端连接
    client_socket.close()

# 关闭服务器套接字
server_socket.close()
