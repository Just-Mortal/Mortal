# TIME : 2023/11/2 21:05

import socket
import time
import statistics
import random
from datetime import datetime

server_name = 'localhost'  # 服务器地址
server_port = 12000  # 服务器端口
client_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)  # 创建UDP套接字

rtt_list = []  # 存储每个数据包的往返时间

packet_loss_rate = 0.2  # 设定丢包率为 20%

for seq in range(1, 11):  # 发送10个ping消息
    send_time = datetime.now()
    message = f"Ping {seq}"

    # 在发送消息之前，模拟数据包丢失
    if random.random() < packet_loss_rate:
        print("Packet lost")
        rtt_list.append(None)  # 记录丢包，添加 None 到 RTT 列表
        continue  # 跳过当前循环，不发送消息

    client_socket.sendto(message.encode(), (server_name, server_port))  # 发送消息到服务器

    client_socket.settimeout(1)  # 设置1秒超时

    try:
        modified_message, server_address = client_socket.recvfrom(2048)  # 接收pong消息
        receive_time = datetime.now()
        rtt = (receive_time - send_time).total_seconds()  # 计算往返时间
        rtt_list.append(rtt)  # 记录RTT
        print(f"Pong received from {server_address[0]}: RTT = {rtt} seconds")
    except socket.timeout:
        print(f"Request timeout for Ping {seq}")
        rtt_list.append(None)  # 如果超时，记录 None 到 RTT 列表

    time.sleep(1 + random.uniform(0, 1))  # 模拟发送间隔，可选

client_socket.close()  # 关闭套接字

rtt_list = [rtt for rtt in rtt_list if rtt is not None]  # 去除未收到响应的RTT

if rtt_list:
    average_rtt = statistics.mean(rtt_list)
    print(f"\nAverage RTT for received pings: {average_rtt} seconds")
else:
    print("\nNo responses received.")
