# TIME : 2023/10/30 20:13

import socket

# 创建一个TCP套接字
client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# 连接到服务器
server_address = ('127.0.0.1', 12345)
client_socket.connect(server_address)

# 发送文件名请求
file_name = r"D:\概率论\Experiment 1"
client_socket.send(file_name.encode())
print(f"发送文件名请求: {file_name}")

# 接收文件或错误消息
response = client_socket.recv(1024).decode()
if response == "文件不存在":
    print("接收到错误消息：文件不存在")
else:
    with open(file_name, 'wb') as file:
        file.write(response.encode())
    print(f"已接收文件: {file_name}")

# 关闭客户端套接字
client_socket.close()
