# TIME : 2023/11/20 20:43

import socket
import random

# 创建UDP套接字
server_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
# 绑定到本地IP和端口
server_socket.bind(('localhost', 12345))
loss_rate = 0.5
# 服务器持续运行等待接收数据包
while True:
    # 接收客户端数据包
    message, client_address = server_socket.recvfrom(1024)
    if(random.random() < loss_rate):  # 设置的丢包率
        print(f"Packet lost: {message.decode()}")
        continue                     # 模拟数据包丢失
    else:
         # 如果数据包未丢失，打印收到的数据包信息
        print(f"Received {message.decode()} from {client_address}")
         # 发送ACK给客户端
        ack = f"Ack for {message.decode()}"
        server_socket.sendto(ack.encode(), client_address)
        continue