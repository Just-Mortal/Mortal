# TIME : 2023/11/20 20:44

import socket
import datetime
import statistics

# 创建UDP套接字
client_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
# 服务器的IP地址和端口号
server_address = ('localhost', 12345)
num_packets = 10
rtts = []  # 记录RTT的列表
sent_packets = 0  # 发送的数据包数量，包括重发
start_time = datetime.datetime.now()  # 开始发送数据的时间
# 发送数据包
for i in range(num_packets):
    message = f'Packet {i}'
    while True:

        # 记录发送时间
        send_time = datetime.datetime.now()
        # 发送数据包到服务器
        client_socket.sendto(message.encode(), server_address)
        sent_packets += 1  # 发送数据包计数器加一
        # 设置接收ACK的超时时间为1秒
        client_socket.settimeout(1)

        try:
            # 等待接收服务器的ACK
            ack, server = client_socket.recvfrom(1024)
            # 记录收到ACK的时间
            recv_time = datetime.datetime.now()
            # 计算并记录RTT
            rtt = (recv_time - send_time).total_seconds()
            rtts.append(rtt)
            # 打印收到的ACK和RTT
            print(f"Received ack for {message}: {ack.decode()} with RTT: {rtt}s")
            break  # 成功收到ACK，跳出循环

        except socket.timeout:
            # 如果超时未收到ACK，打印超时信息，并在下一次循环中重发数据包
            print(f"Timeout for {message}, resending...")

end_time = datetime.datetime.now()  # 结束发送数据的时间
total_time = (end_time - start_time).total_seconds()  # 计算总时间
# 计算并打印平均RTT和丢包率
average_rtt = statistics.mean(rtts) if rtts else 0
# 使用发送计数器和RTT列表长度来计算丢包率
actual_loss_rate = ((sent_packets - len(rtts)) / sent_packets) * 100
print(f"Average RTT for {num_packets} packets: {average_rtt}s")
print(f"Total time for sending packets: {total_time}s")
print(f"Actual packet loss rate: {actual_loss_rate}%\n")

# 关闭客户端套接字
client_socket.close()
